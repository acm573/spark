package io.keepcoding.spark.exercise.streaming
import scala.concurrent.ExecutionContext.Implicits.global
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType, TimestampType}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.sql.functions._

import scala.concurrent.{Await, Future}
import scala.concurrent.duration.Duration

object AntenaStreamingJob extends StreamingJob {

  /* Paso 1, se debe crear la SparkSession */
  override val spark: SparkSession = SparkSession
    .builder()
    .master("local[20]")
    .appName("Ejercicio Final SQL Streaming")
    .getOrCreate()


  /* Paso 3, se comienza con la lectura de kafka */
  override def readFromKafka(kafkaServer: String, topic: String): DataFrame = {
    spark
      .readStream
      .format("kafka")
      .option("kafka.bootstrap.servers",kafkaServer)
      .option("subscribe", topic)
      .load()
  }

  /* se define durante la implementación del Paso 6 */
  import spark.implicits._

  /* Paso 6. Los datos requieren de un parseo para poder ser legibles los datos */
  /* este ajuste se hara con este método */
  override def parserJsonData(dataFrame: DataFrame): DataFrame = {
    //Se requiere definir un esquema del json para poder extraer la información
    //esta información está definida en la cabecera de los datos del ejercicio
    val jsonSchema = StructType(Seq(
      StructField("timestamp", TimestampType, nullable = false),
      StructField("id", StringType, nullable = false),
      StructField("metric", StringType, nullable = false),
      StructField("value", IntegerType, nullable = false)
    ))

    //lo que se ha configurado es el esquema del dataframe que se recibe
    //para poder comenzar con la extracción de la información vía select
    //se necesita agregar import spark.implicits,_
    //junto con el import de import org.apache.spark.sql.functions._

    //vamos a ir seleccionando la información por columnas
    dataFrame
      //saca el value que contiene los elementos definidos por timestamp, id, metric, value
      //por lo que se castea a String y lo pone en json con un nombre "json"
      .select(from_json($"value".cast(StringType), jsonSchema).as("json"))
      //ahora hay que navegar dentro del json que se ha obtenido con la estructura del esquema
      .select($"json.*")

    //esto nos devuelve un dataframe con json parseado
  }

  /* Paso 9, ahora se trabaja en la extracción de loa metadatos de SQL */
  override def readAntennaMetadata(jdbcURI: String, jdbcTable: String, user: String, password: String): DataFrame = {
    spark
      .read
      .format("jdbc")
      .option("url", jdbcURI)
      .option("dbtable",jdbcTable)
      .option("user", user)
      .option("password",password)
      .load()

    //listo, en este punto ya tenemos la consulta de la tabla indicada como dataframe

  }

  /* Paso 13, ahora se procede a hacer el join entre los datos del json parseado y los metadatos */
  override def enrichAntennaWithMetadata(antennaDF: DataFrame, metadataDF: DataFrame): DataFrame = {

    antennaDF.as("a")
      .join(metadataDF.as("b"),
      $"a.id" === $"b.id")

    //este join nos dejará duplicado el campo de id, por lo que se debe eliminar uno de ellos
      .drop($"b.id")

    //ya tenemos el join de los dataframe
  }

  /* Paso 16, procedemos a implementar el primer requerimiento del ejercicio   */
  /* que dice: park Structured Streaming, hace métricas agregadas cada 5 minutos y guarda en PostgreSQL.
      AVG, MAX, MIN (device_counts) por coordenadas GPS.
   */
  override def computeDevicesCountByCoordinates(dataFrame: DataFrame): DataFrame = {

    //se recibe el DF con la información y hay que comenzar filtrando
    dataFrame
      //se pone primero un filtro, porque el requerimiento indique que deben hacerse las metricas
      //en los campos de tipo "devices_count
      .filter($"metric" === "devices_count")
    //ahora seleccionamos los campos que nos interesan
      .select($"timestamp", $"location", $"value")
    //ahora se implementa el agrupamiento junto con la ventana
      // se agrega el withWatermark para evitar los campos retrazados
      .withWatermark("timestamp","10 seconds")  //1 minute
      .groupBy($"location", window($"timestamp", "30 seconds"))  //5 minutes

    //ahora siguen las agregaciones y se debe tener en cuenta la estructura de la tabla en SQL
      //porque esta información se va a guardar ahí y deben corresponder los nombres de los campos
      //CREATE TABLE antenna_agg (location TEXT, date TIMESTAMP, avg_devices_count BIGINT, max_devices_count BIGINT, min_devices_count BIGINT);
      .agg(
        avg($"value").as("avg_devices_count"),
        max($"value").as("max_devices_count"),
        min($"value").as("min_devices_count")
      )

    //en este punto se tiene una estructura que se debe depurar
    /*Ejecuntando el paso 18 obtenemos que hay una estructura:
    +--------------------+--------------------+-----------------+-----------------+-----------------+
        |            location|              window|avg_devices_count|max_devices_count|min_devices_count|
        +--------------------+--------------------+-----------------+-----------------+-----------------+
        |36.420476, -5.822540|[2022-10-21 02:34...|              0.0|                0|                0|
        |36.459686, -6.113992|[2022-10-21 02:34...|              5.0|                5|                5|
        |36.297735, -5.835083|[2022-10-21 02:34...|              0.0|                0|                0|
        |36.478596, -5.968923|[2022-10-21 02:34...|              5.0|                5|                5|
        |36.454685, -6.067934|[2022-10-21 02:34...|             10.0|               10|               10|
        +--------------------+--------------------+-----------------+-----------------+-----------------+
     */
    // se debe ajustar a lo que espera la tabla de SQL
    // adicionalmente, la columna window está integrada por dos elementos:
    // inicio y fin

    //se comienza con el select de los datos de interes
      .select($"location", $"window.start".as("date"), $"avg_devices_count", $"max_devices_count", $"min_devices_count")

    //listo, ya se tiene ajustada la estructura del DF


  }

  /* Paso 21 ahora vamos a generar la salida para nuestra tabla en SQL */
  override def writeToJdbc(dataFrame: DataFrame, jdbcURI: String, jdbcTable: String, user: String, password: String): Future[Unit] = Future {
    //tomamos el dataframe
    dataFrame     //es tipo stream
      .writeStream
      .foreachBatch(
        /*
           el batch es el contenido del dataframe
            +--------------------+-------------------+-----------------+-----------------+-----------------+
            |            location|               date|avg_devices_count|max_devices_count|min_devices_count|
            +--------------------+-------------------+-----------------+-----------------+-----------------+
            |36.454685, -6.067934|2022-10-21 02:45:30|             10.0|               10|               10|
            |36.478596, -5.968923|2022-10-21 02:45:30|              0.0|                0|                0|
            |36.297735, -5.835083|2022-10-21 02:45:30|              0.0|                0|                0|
            |36.420476, -5.822540|2022-10-21 02:45:30|              4.0|                4|                4|
            |36.459686, -6.113992|2022-10-21 02:45:30|              6.0|                6|                6|
            +--------------------+-------------------+-----------------+-----------------+-----------------+

            y el id es el identificador del batch:
            -------------------------------------------
            Batch: 8
            -------------------------------------------
         */

        (batch : DataFrame, _ : Long) => {
          batch   //ya es un dataframe normal
            .write
            .mode(SaveMode.Append)
            .format("jdbc")
            .option("url", jdbcURI)
            .option("dbtable", jdbcTable)
            .option("user", user)
            .option("password", password)
            .save()
        }
      )

      //para resolver el futuro
      .start()
      .awaitTermination()

    //finalmente se agrega import scala.concurrent.ExecutionContext.Implicits.global
  }


  /* Paso 29. Se implementa la funcion de almacenamiento en parquet*/
  override def writeToStorage(dataFrame: DataFrame, storageRootPath: String): Future[Unit] = Future {
    dataFrame
      .select(
        $"timestamp", $"id", $"metric", $"value",
        year($"timestamp").as("year"),
        month($"timestamp").as("month"),
        dayofmonth($"timestamp").as("day"),
        hour($"timestamp").as("hour")
      )
      .writeStream
      .format("parquet")
      .option("path", s"$storageRootPath/data")
      .option("checkpointLocation", s"$storageRootPath/checkpoint")
      .partitionBy("year", "month", "day", "hour")
      .start
      .awaitTermination()
  }



  /* Paso 2, se implementa un main para poder ir probando las implementaciones */
  def main(args: Array[String]): Unit = {
    /* Paso 10, defino como variables los parámetros asociados al SQL en cloud */
    val IpServer = "35.222.25.88"
    val url = s"jdbc:postgresql://$IpServer:5432/postgres"
    val username = "postgres"
    val password = "postgres"


    //lo que hará el main es llamar  run del trait
    //mientras vamos ir invocando los métodos del trait

    /* Paso 4, se puede comenzar a utilizar lo que se está leyendeo de kafka */
    /* importante, no olvidar el puerto en la dirección IP */
    val kafkaDF = readFromKafka("34.67.66.210:9092", "antenna_telemetry")

    /* Paso 7, ahora obtenemos el dato que se ha parseado a json */
    val parseDF = parserJsonData(kafkaDF)

    /* Paso 11, ahora se hace uso del dataframe del SQL */
    val metadaDF = readAntennaMetadata(url, "metadata", username, password)

    /* Paso 14, ahora consumimos el DF enriquecido*/
    val enrichDF = enrichAntennaWithMetadata(parseDF, metadaDF)

    /* Paso 17, vemos la información sin depurar que se almacenará en el SQL */
    val temp = computeDevicesCountByCoordinates(enrichDF)

    /* Paso 19, declaramos la variable del DF final para el sQL */
    val countByLocation = computeDevicesCountByCoordinates(enrichDF)

    /* Paso 23, ahora enviamos la información al SQL */
    val jdbcFuture = writeToJdbc(countByLocation, url, "antenna_agg", username, password)

    /* Paso 24, se procede a invocar al almacenamiento PARQUET */
    val storageFuture =  writeToStorage(parseDF, "/tmp/antenna_parquet/")

    /*Paso 5, se utiliza el contenido del paso 4 en consola */
    /* la salida de este paso es:
    -------------------------------------------
    Batch: 1
    -------------------------------------------
    +----+--------------------+-----------------+---------+------+--------------------+-------------+
    | key|               value|            topic|partition|offset|           timestamp|timestampType|
    +----+--------------------+-----------------+---------+------+--------------------+-------------+
    |null|[7B 22 74 69 6D 6...|antenna_telemetry|        0|   855|2022-10-21 01:52:...|            0|
    |null|[7B 22 74 69 6D 6...|antenna_telemetry|        0|   856|2022-10-21 01:52:...|            0|
    ... ... .. ...
    |null|[7B 22 74 69 6D 6...|antenna_telemetry|        0|   868|2022-10-21 01:52:...|            0|
    |null|[7B 22 74 69 6D 6...|antenna_telemetry|        0|   869|2022-10-21 01:52:...|            0|
    +----+--------------------+-----------------+---------+------+--------------------+-------------+
     */
    /*
    kafkaDF
      .writeStream
      .format("console")
      .start()
      .awaitTermination()
     */


    /* Paso 8, cambiamos de dataframe por el json  para ver si contenido */
    /* Salida de este paso es:
    +-------------------+--------------------+-------------+-----+
    |          timestamp|                  id|       metric|value|
    +-------------------+--------------------+-------------+-----+
    |2022-10-21 01:50:31|00000000-0000-000...|       status|    0|
    |2022-10-21 01:50:31|22222222-2222-222...|       status|    0|
    ... ... ...
    |2022-10-21 01:50:31|33333333-3333-333...|      battery|  100|
    |2022-10-21 01:50:31|44444444-4444-444...|      battery|   91|
    +-------------------+--------------------+-------------+-----+

    Ahora hay que enriqueser los mensajes con la información que se tiene
    de metadatos en SQL
     */
    /*parseDF
      .writeStream
      .format("console")
      .start()
      .awaitTermination()
    */

    /* Paso 12, ahora cambiamos la consulta para ver el dataFrame */
    /* la salida es la siguiente
    +--------------------+-------+-------+--------------------+
    |                  id|  model|version|            location|
    +--------------------+-------+-------+--------------------+
    |00000000-0000-000...|CH-2020|  1.0.0|36.454685, -6.067934|
    |11111111-1111-111...|CH-2121|  1.2.0|36.459686, -6.113992|
    |22222222-2222-222...|CH-2020|  1.0.1|36.478596, -5.968923|
    |33333333-3333-333...|CH-3311|  1.0.0|36.420476, -5.822540|
    |44444444-4444-444...|CH-2121|  1.2.0|36.297735, -5.835083|
    +--------------------+-------+-------+--------------------+
     */
    /*
    metadaDF
      .show()
     */

    /*Paso 15, visualizamos la información del DF que se ha enriquecido*/
    /* la salida es la siguiente
    +-------------------+--------------------+-------------+-----+-------+-------+--------------------+
    |          timestamp|                  id|       metric|value|  model|version|            location|
    +-------------------+--------------------+-------------+-----+-------+-------+--------------------+
    |2022-10-21 02:13:07|11111111-1111-111...|       status|    0|CH-2121|  1.2.0|36.459686, -6.113992|
    |2022-10-21 02:13:07|11111111-1111-111...|devices_count|    5|CH-2121|  1.2.0|36.459686, -6.113992|
      ....    ....      ....      ....
    |2022-10-21 02:13:07|33333333-3333-333...|devices_count|    0|CH-3311|  1.0.0|36.420476, -5.822540|
    |2022-10-21 02:13:07|33333333-3333-333...|      battery|  100|CH-3311|  1.0.0|36.420476, -5.822540|
    +-------------------+--------------------+-------------+-----+-------+-------+--------------------+
     */
    /*
    enrichDF
      .writeStream
      .format("console")
      .start()
      .awaitTermination()
     */

    /*Paso 18, consulta previa del proceso antes de depuracion */
    /* la salida es:
    +--------------------+--------------------+-----------------+-----------------+-----------------+
    |            location|              window|avg_devices_count|max_devices_count|min_devices_count|
    +--------------------+--------------------+-----------------+-----------------+-----------------+
    |36.420476, -5.822540|[2022-10-21 02:34...|              0.0|                0|                0|
    |36.459686, -6.113992|[2022-10-21 02:34...|              5.0|                5|                5|
    |36.297735, -5.835083|[2022-10-21 02:34...|              0.0|                0|                0|
    |36.478596, -5.968923|[2022-10-21 02:34...|              5.0|                5|                5|
    |36.454685, -6.067934|[2022-10-21 02:34...|             10.0|               10|               10|
    +--------------------+--------------------+-----------------+-----------------+-----------------+
     */
    /*temp
      .writeStream
      .format("console")
      .start()
      .awaitTermination()
     */

    /*Paso 20 consulta del DF depurado */
    /* la salida es:
    +--------------------+-------------------+-----------------+-----------------+-----------------+
    |            location|               date|avg_devices_count|max_devices_count|min_devices_count|
    +--------------------+-------------------+-----------------+-----------------+-----------------+
    |36.297735, -5.835083|2022-10-21 02:43:30|              0.0|                0|                0|
    |36.478596, -5.968923|2022-10-21 02:43:30|              5.0|                5|                5|
    |36.459686, -6.113992|2022-10-21 02:43:30|              5.0|                5|                5|
    |36.454685, -6.067934|2022-10-21 02:43:30|             10.0|               10|               10|
    |36.420476, -5.822540|2022-10-21 02:43:30|              0.0|                0|                0|
    +--------------------+-------------------+-----------------+-----------------+-----------------+

    countByLocation
      .writeStream
      .format("console")
      .start()
      .awaitTermination()
    */

    /* Paso 25, se actualiza para gestionar los Future */
    Await.result(Future.sequence(Seq(jdbcFuture, storageFuture)), Duration.Inf)

  }
}
